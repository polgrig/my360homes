var APP_DATA = {
  "scenes": [
    {
      "id": "0-",
      "name": "кладовка",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.739715995744339,
          "pitch": 0.13745445252188127,
          "rotation": 0,
          "target": "1-"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-",
      "name": "коридор",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1632,
      "initialViewParameters": {
        "yaw": 2.7208861264744924,
        "pitch": 0.12888426513712758,
        "fov": 1.4571702545951333
      },
      "linkHotspots": [
        {
          "yaw": 1.361038761868116,
          "pitch": 0.22544128871410152,
          "rotation": 0,
          "target": "0-"
        },
        {
          "yaw": -3.0796720769920967,
          "pitch": 0.21519777867947099,
          "rotation": 6.283185307179586,
          "target": "2-"
        },
        {
          "yaw": -1.979831148186765,
          "pitch": 0.3704135386216141,
          "rotation": 6.283185307179586,
          "target": "3-"
        },
        {
          "yaw": 2.3170816365558187,
          "pitch": 0.27002748340986393,
          "rotation": 6.283185307179586,
          "target": "4-"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-",
      "name": "кухня",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        },
        {
          "tileSize": 512,
          "size": 4096
        }
      ],
      "faceSize": 4096,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    },
    {
      "id": "3-",
      "name": "ванная",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.023151053002189,
          "pitch": 0.01743009218341207,
          "rotation": 6.283185307179586,
          "target": "1-"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-",
      "name": "комната",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1632,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.15057356703375113,
          "pitch": 0.1677828864830957,
          "rotation": 0,
          "target": "1-"
        },
        {
          "yaw": -2.957969137546211,
          "pitch": 0.33667595386420857,
          "rotation": 0,
          "target": "5-"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5-",
      "name": "балкон",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.560339458220392,
          "pitch": 0.1562954981654343,
          "rotation": 0,
          "target": "2-"
        },
        {
          "yaw": -0.6805533479276527,
          "pitch": 0.14051433687594894,
          "rotation": 4.71238898038469,
          "target": "4-"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
